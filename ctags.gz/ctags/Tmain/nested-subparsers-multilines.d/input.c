DEFINE_EVENT(a,
			 b);

DEFINE_HOOK(h,
			i);

int
main(void)
{
}
