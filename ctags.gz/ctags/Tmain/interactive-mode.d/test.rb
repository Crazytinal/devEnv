class Test
  def foobar
  end

  def baz(a=1)
  end
end
