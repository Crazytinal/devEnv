int dont_capture_me(void)
{
	return 0;
}
