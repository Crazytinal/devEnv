int capture_me_1(void)
{
	return 0;
}
