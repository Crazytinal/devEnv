mv ~/.zshrc ~/.zshrc.orig
mv ~/.oh-my-zsh ~/.oh-my-zsh.orig
cp ~/.bashrc ~/.bashrc.orig
#cp bashrc  ~/c2sh.sh
cp bashrc  ~/.bashrc
cp  oh-my-zsh -r  ~/.oh-my-zsh
cp ~/.oh-my-zsh/templates/zshrc.zsh-template ~/.zshrc
cd autojump; ./install.py

